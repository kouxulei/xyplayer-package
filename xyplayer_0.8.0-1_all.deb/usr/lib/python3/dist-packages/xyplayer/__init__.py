# Copyright (C) 2013-2014 Zheng-Yejian <1035766515@qq.com>
# Use of this source code is governed by GPLv3 license that can be found
# in the LICENSE file.

__version__ = '0.8.0-1'
__doc__ = '''This is a simple musicplayer that can search, play, download musics from the Internet.
'''
